
var tablinks=document.getElementsByClassName('tab-links')
var tabcontents=document.getElementsByClassName('tab-contents')

function opentab(tabname){
    for(tabl of tablinks){
        tabl.classList.remove("active-links")
    }
    for(tabcon of tabcontents){
        tabcon.classList.remove("active-tab");
    }

    document.getElementById(tabname).classList.add('active-tab')
}

